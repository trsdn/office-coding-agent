---
name: Excel Analytics
description: Guidance for analytics workflows and structured output.
version: 1.0.0
tags:
  - excel
  - analytics
---

When solving Excel analytics tasks:
- Explain assumptions briefly
- Prefer clear table outputs
- Summarize findings and next actions
