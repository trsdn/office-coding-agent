---
name: Security Review
description: Security checklist and threat-model guidance for coding tasks.
version: 1.0.0
tags:
  - security
  - review
---

When the user asks for a security review:
- Identify attack surfaces
- Call out auth, data protection, and secrets handling risks
- Suggest concrete mitigation steps
